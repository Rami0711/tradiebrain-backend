import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
)

// ── Users ────────────────────────────────────────────

export async function getUser(phone) {
  const { data } = await supabase
    .from('users')
    .select('*')
    .eq('phone', phone)
    .single()
  return data
}

export async function createUser(phone, name, trade) {
  const trialEnds = new Date()
  trialEnds.setDate(trialEnds.getDate() + parseInt(process.env.TRIAL_DAYS || 14))

  const { data, error } = await supabase
    .from('users')
    .insert({
      phone,
      name: name || null,
      trade: trade || null,
      status: 'trial',
      trial_ends_at: trialEnds.toISOString(),
      invoice_count: 0,
      created_at: new Date().toISOString()
    })
    .select()
    .single()

  if (error) throw error
  return data
}

export async function updateUser(phone, updates) {
  const { data, error } = await supabase
    .from('users')
    .update(updates)
    .eq('phone', phone)
    .select()
    .single()
  if (error) throw error
  return data
}

export async function isUserActive(user) {
  if (!user) return false
  if (user.status === 'active') return true
  if (user.status === 'trial') {
    return new Date(user.trial_ends_at) > new Date()
  }
  return false
}

export async function incrementInvoiceCount(phone) {
  const { data: user } = await supabase
    .from('users')
    .select('invoice_count')
    .eq('phone', phone)
    .single()

  await supabase
    .from('users')
    .update({ invoice_count: (user?.invoice_count || 0) + 1 })
    .eq('phone', phone)
}

// ── Jobs ─────────────────────────────────────────────

export async function saveJob(phone, job) {
  const { data, error } = await supabase
    .from('jobs')
    .insert({
      user_phone: phone,
      type: job.type,                   // 'invoice' | 'quote'
      client_name: job.clientName,
      client_address: job.clientAddress || null,
      description: job.description,
      labour_amount: job.labourAmount || 0,
      materials_amount: job.materialsAmount || 0,
      total_amount: job.totalAmount,
      vat_amount: job.vatAmount || 0,
      cis_deduction: job.cisDeduction || 0,
      invoice_number: job.invoiceNumber || null,
      pdf_url: job.pdfUrl || null,
      job_date: job.jobDate || new Date().toISOString().split('T')[0],
      created_at: new Date().toISOString()
    })
    .select()
    .single()

  if (error) throw error
  return data
}

export async function getJobsForQuarter(phone, year, quarter) {
  // Quarter date ranges
  const ranges = {
    1: { start: `${year}-04-06`, end: `${year}-07-05` },
    2: { start: `${year}-07-06`, end: `${year}-10-05` },
    3: { start: `${year}-10-06`, end: `${year + 1}-01-05` },
    4: { start: `${year + 1}-01-06`, end: `${year + 1}-04-05` }
  }
  const range = ranges[quarter]

  const { data, error } = await supabase
    .from('jobs')
    .select('*')
    .eq('user_phone', phone)
    .eq('type', 'invoice')
    .gte('job_date', range.start)
    .lte('job_date', range.end)
    .order('job_date', { ascending: true })

  if (error) throw error
  return data || []
}

export async function getJobsCurrentMonth(phone) {
  const now = new Date()
  const start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0]
  const end = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().split('T')[0]

  const { data } = await supabase
    .from('jobs')
    .select('*')
    .eq('user_phone', phone)
    .eq('type', 'invoice')
    .gte('job_date', start)
    .lte('job_date', end)

  return data || []
}

// ── Expenses ─────────────────────────────────────────

export async function saveExpense(phone, expense) {
  const { data, error } = await supabase
    .from('expenses')
    .insert({
      user_phone: phone,
      description: expense.description,
      amount: expense.amount,
      category: expense.category,
      expense_date: expense.date || new Date().toISOString().split('T')[0],
      created_at: new Date().toISOString()
    })
    .select()
    .single()

  if (error) throw error
  return data
}

export async function getExpensesForQuarter(phone, year, quarter) {
  const ranges = {
    1: { start: `${year}-04-06`, end: `${year}-07-05` },
    2: { start: `${year}-07-06`, end: `${year}-10-05` },
    3: { start: `${year}-10-06`, end: `${year + 1}-01-05` },
    4: { start: `${year + 1}-01-06`, end: `${year + 1}-04-05` }
  }
  const range = ranges[quarter]

  const { data } = await supabase
    .from('expenses')
    .select('*')
    .eq('user_phone', phone)
    .gte('expense_date', range.start)
    .lte('expense_date', range.end)
    .order('expense_date', { ascending: true })

  return data || []
}

export default supabase
