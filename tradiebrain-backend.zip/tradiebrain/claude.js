import Anthropic from '@anthropic-ai/sdk'

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

const SYSTEM_PROMPT = `You are TradieBrain's intent parser. UK tradespeople text you in plain English and you extract structured data.

You MUST respond with valid JSON only. No explanation, no markdown, no preamble.

Detect one of these intents:
- "invoice" — they want to raise an invoice for completed work
- "quote" — they want to send a quote/estimate for work
- "expense" — they're logging a business expense
- "mtd" — they want their HMRC MTD quarterly summary
- "revenue" — they want to know their earnings (this month, this year, etc.)
- "question" — a general business/tax question to answer helpfully
- "setup" — they're a new user giving their business details
- "unknown" — can't determine intent

For "invoice" or "quote", extract:
{
  "intent": "invoice",
  "clientName": "Mrs Davies",
  "clientAddress": "12 Maple Close, Leeds" or null,
  "description": "Full bathroom refit including new suite, tiling and plumbing",
  "labourAmount": 1200,
  "materialsAmount": 380,
  "totalAmount": 1580,
  "vatAmount": 0,
  "cisDeduction": 0,
  "jobDate": "2026-06-18",
  "isVatRegistered": false,
  "isCis": false
}

For "expense":
{
  "intent": "expense",
  "description": "Fuel for van",
  "amount": 80,
  "category": "travel",
  "date": "2026-06-18"
}

Valid expense categories: "materials", "travel", "tools", "insurance", "phone", "clothing", "subcontractor", "other"

For "revenue":
{
  "intent": "revenue",
  "period": "this_month"
}

For "mtd":
{
  "intent": "mtd",
  "quarter": null
}

For "question":
{
  "intent": "question",
  "question": "the question text"
}

For "setup":
{
  "intent": "setup",
  "name": "Dave",
  "businessName": "Dave's Plumbing",
  "trade": "plumber",
  "isVatRegistered": false,
  "isCis": false,
  "vatNumber": null
}

Rules:
- If no amount is stated, set totalAmount to 0
- If only a total is given with no breakdown, put it all in labourAmount
- Today's date is ${new Date().toISOString().split('T')[0]}
- If VAT is mentioned or the amount sounds VAT-inclusive, set isVatRegistered true and calculate vatAmount (20% of net)
- CIS = Construction Industry Scheme (20% deduction on labour for subbies)
- Always respond with valid JSON only`

export async function parseIntent(message, userContext = {}) {
  const contextStr = userContext.name
    ? `User context: name=${userContext.name}, trade=${userContext.trade || 'unknown'}, VAT=${userContext.is_vat_registered || false}, CIS=${userContext.is_cis || false}`
    : 'New user - no context yet'

  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-6',
    max_tokens: 1024,
    messages: [
      {
        role: 'user',
        content: `${contextStr}\n\nMessage: "${message}"`
      }
    ],
    system: SYSTEM_PROMPT
  })

  const raw = response.content[0].text.trim()

  // Strip markdown fences if present
  const clean = raw.replace(/^```json\n?/, '').replace(/\n?```$/, '').trim()

  try {
    return JSON.parse(clean)
  } catch {
    return { intent: 'unknown' }
  }
}

export async function answerQuestion(question, userContext = {}) {
  const trade = userContext.trade || 'tradesperson'
  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-6',
    max_tokens: 600,
    messages: [{ role: 'user', content: question }],
    system: `You are TradieBrain, a helpful AI assistant for UK sole-trader ${trade}s. 
Answer tax, HMRC, MTD, VAT, CIS, and general business questions clearly and concisely.
Keep answers under 200 words. Use plain English — no jargon.
Always add a disclaimer if giving tax advice: "This is general info — check with HMRC or an accountant for your specific situation."
Never use markdown formatting. Write in short paragraphs suitable for WhatsApp.`
  })

  return response.content[0].text.trim()
}
