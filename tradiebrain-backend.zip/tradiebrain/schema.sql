-- ── Run this in Supabase: Dashboard → SQL Editor → New Query ─────────────────

-- Users table
create table if not exists users (
  id                    uuid default gen_random_uuid() primary key,
  phone                 text unique not null,           -- "whatsapp:+447700900000"
  name                  text,
  business_name         text,
  trade                 text,
  address               text,
  email                 text,
  status                text default 'trial',           -- 'trial' | 'active' | 'cancelled'
  plan                  text default 'pro',             -- 'starter' | 'pro' | 'teams'
  trial_ends_at         timestamptz,
  setup_complete        boolean default false,
  is_vat_registered     boolean default false,
  vat_number            text,
  is_cis                boolean default false,
  bank_account          jsonb,                          -- {name, sort_code, account_number}
  stripe_customer_id    text,
  stripe_subscription_id text,
  invoice_count         integer default 0,
  created_at            timestamptz default now()
);

-- Jobs table (invoices and quotes)
create table if not exists jobs (
  id                uuid default gen_random_uuid() primary key,
  user_phone        text references users(phone) on delete cascade,
  type              text not null,                      -- 'invoice' | 'quote'
  client_name       text,
  client_address    text,
  description       text,
  labour_amount     numeric(10,2) default 0,
  materials_amount  numeric(10,2) default 0,
  total_amount      numeric(10,2) not null,
  vat_amount        numeric(10,2) default 0,
  cis_deduction     numeric(10,2) default 0,
  invoice_number    text,
  pdf_url           text,
  job_date          date default current_date,
  created_at        timestamptz default now()
);

-- Expenses table
create table if not exists expenses (
  id            uuid default gen_random_uuid() primary key,
  user_phone    text references users(phone) on delete cascade,
  description   text not null,
  amount        numeric(10,2) not null,
  category      text default 'other',                  -- see categories below
  expense_date  date default current_date,
  created_at    timestamptz default now()
);

-- Valid expense categories:
-- 'materials' | 'travel' | 'tools' | 'insurance' | 'phone' | 'clothing' | 'subcontractor' | 'other'

-- Indexes for performance
create index if not exists jobs_user_phone_idx on jobs(user_phone);
create index if not exists jobs_job_date_idx on jobs(job_date);
create index if not exists expenses_user_phone_idx on expenses(user_phone);
create index if not exists expenses_expense_date_idx on expenses(expense_date);

-- Storage bucket for PDF documents
-- Run this separately in Supabase Storage settings:
-- Create a bucket called "documents" and set it to PUBLIC
