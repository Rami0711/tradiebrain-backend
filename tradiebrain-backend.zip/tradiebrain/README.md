# TradieBrain — Backend

WhatsApp AI admin assistant for UK sole-trader tradespeople.

## Files

| File | What it does |
|------|-------------|
| `server.js` | Main Express server, Twilio webhook, Stripe webhook |
| `handlers.js` | All intent handlers (invoice, quote, expense, MTD, revenue) |
| `claude.js` | Anthropic API — intent parsing + question answering |
| `pdf.js` | PDF invoice/quote generator + Supabase upload |
| `db.js` | Supabase database helpers |
| `schema.sql` | Database tables — paste into Supabase SQL editor |
| `.env.example` | Copy to `.env` and fill in your keys |

---

## Deploy in 6 steps

### 1. Set up Supabase

1. Go to supabase.com → New project
2. Dashboard → SQL Editor → New Query
3. Paste the contents of `schema.sql` → Run
4. Go to Storage → Create bucket called `documents` → set to **Public**
5. Copy your Project URL and service_role key (Settings → API)

### 2. Set up Stripe

1. stripe.com → Products → Add product for each plan:
   - Starter: £5.99/month recurring
   - Pro: £9.99/month recurring  
   - Teams: £24/month recurring
2. For each product → Create Payment Link
3. Copy the three payment link URLs
4. Developers → Webhooks → Add endpoint:
   - URL: `https://your-app.up.railway.app/stripe-webhook`
   - Events: `checkout.session.completed`, `customer.subscription.deleted`, `invoice.payment_failed`
5. Copy the webhook signing secret

### 3. Push to GitHub

```bash
git init
git add .
git commit -m "Initial TradieBrain backend"
git remote add origin https://github.com/YOUR_USERNAME/tradiebrain-backend.git
git push -u origin main
```

### 4. Deploy to Railway

1. railway.app → New Project → Deploy from GitHub repo
2. Select your tradiebrain-backend repo
3. Railway auto-detects Node.js and deploys
4. Settings → Variables → add ALL variables from `.env.example`:

```
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
TWILIO_WHATSAPP_NUMBER=whatsapp:+14155238886
ANTHROPIC_API_KEY=
SUPABASE_URL=
SUPABASE_SERVICE_KEY=
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
STRIPE_LINK_STARTER=
STRIPE_LINK_PRO=
STRIPE_LINK_TEAMS=
APP_URL=https://your-app.up.railway.app
TRIAL_DAYS=14
```

5. Copy your Railway public URL (e.g. `https://tradiebrain-production.up.railway.app`)

### 5. Connect Twilio webhook

1. Twilio Console → Messaging → Try it out → Send a WhatsApp message
2. Sandbox Settings
3. Paste your Railway URL + `/webhook` into "When a message comes in":
   `https://tradiebrain-production.up.railway.app/webhook`
4. Set method to **HTTP POST**
5. Save

### 6. Test it

Text your Twilio sandbox WhatsApp number:
- `"Hi"` → should get welcome message
- `"Dave, plumber"` → should get setup confirmation
- `"Invoice Mrs Davies, bathroom refit, £1,400"` → should get invoice PDF
- `"Expense: fuel £65"` → should get expense confirmation
- `"MTD summary"` → should get quarterly report
- `"Is my van insured tax deductible?"` → should get AI answer

---

## Costs at 200 users

| Service | Monthly cost |
|---------|-------------|
| Railway | £5 |
| Twilio WhatsApp | ~£5 |
| Anthropic API | ~£20-40 |
| Supabase | £0 (free tier) |
| **Total** | **~£30-50** |
| **Revenue** | **£2,000** |

---

## Adding your logo to invoices

The logo is drawn programmatically in `pdf.js` using PDFKit shapes.
To use your actual SVG logo file, install `sharp` and convert to PNG:

```bash
npm install sharp
```

Then in `pdf.js` replace the logo drawing section with:
```js
doc.image('./logo.png', 50, 18, { width: 120 })
```

Place your logo PNG at the project root as `logo.png`.
