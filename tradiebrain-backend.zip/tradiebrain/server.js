import 'dotenv/config'
import express from 'express'
import twilio from 'twilio'
import Stripe from 'stripe'
import {
  getUser, createUser, updateUser, isUserActive
} from './db.js'
import { parseIntent } from './claude.js'
import {
  handleNewUser, handleSetup, handleBankSetup,
  handleInvoice, handleQuote, handleExpense,
  handleMTD, handleRevenue, handleQuestion,
  handleTrialExpired, handleHelp, handleUnknown,
  isBankSetupMessage, isNewUserSetupMessage
} from './handlers.js'

const app = express()
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)

// ── Middleware ────────────────────────────────────────────────────────────────
app.use('/stripe-webhook', express.raw({ type: 'application/json' }))
app.use(express.urlencoded({ extended: false }))
app.use(express.json())

// ── Health check ──────────────────────────────────────────────────────────────
app.get('/', (req, res) => {
  res.json({ status: 'TradieBrain is running', time: new Date().toISOString() })
})

// ── WhatsApp webhook ──────────────────────────────────────────────────────────
app.post('/webhook', async (req, res) => {
  // Acknowledge Twilio immediately (must respond within 15s)
  res.set('Content-Type', 'text/xml')
  res.send('<Response></Response>')

  try {
    const { Body: rawMessage, From: phone, MediaUrl0: mediaUrl } = req.body

    if (!rawMessage && !mediaUrl) return
    const message = (rawMessage || '').trim()

    console.log(`[${new Date().toISOString()}] Message from ${phone}: "${message}"`)

    // Get or create user
    let user = await getUser(phone)

    // ── Brand new user ────────────────────────────────
    if (!user) {
      user = await createUser(phone)
      const welcomeMsg = await handleNewUser(phone)
      await sendWhatsApp(phone, welcomeMsg)
      return
    }

    // ── Returning user: check subscription ───────────
    const active = await isUserActive(user)
    if (!active) {
      const msg = await handleTrialExpired(user)
      await sendWhatsApp(phone, msg)
      return
    }

    // ── Handle "help" keyword ─────────────────────────
    if (/^help$/i.test(message)) {
      await sendWhatsApp(phone, await handleHelp())
      return
    }

    // ── Handle bank details setup ─────────────────────
    if (isBankSetupMessage(message)) {
      const response = await handleBankSetup(phone, message)
      if (response) {
        await sendWhatsApp(phone, response)
        return
      }
    }

    // ── Handle new user setup message ─────────────────
    if (!user.setup_complete && isNewUserSetupMessage(message)) {
      const parsed = quickParseSetup(message)
      const response = await handleSetup(phone, parsed)
      await sendWhatsApp(phone, response)
      return
    }

    // ── Parse intent with Claude ──────────────────────
    const parsed = await parseIntent(message, user)
    console.log(`[Intent] ${parsed.intent}`, JSON.stringify(parsed))

    let response
    let pdfUrl = null

    switch (parsed.intent) {
      case 'setup':
        response = await handleSetup(phone, parsed)
        break

      case 'invoice': {
        const result = await handleInvoice(phone, parsed, user)
        if (typeof result === 'object') {
          response = result.message
          pdfUrl = result.pdfUrl
        } else {
          response = result
        }
        break
      }

      case 'quote': {
        const result = await handleQuote(phone, parsed, user)
        if (typeof result === 'object') {
          response = result.message
          pdfUrl = result.pdfUrl
        } else {
          response = result
        }
        break
      }

      case 'expense':
        response = await handleExpense(phone, parsed)
        break

      case 'mtd':
        response = await handleMTD(phone)
        break

      case 'revenue':
        response = await handleRevenue(phone)
        break

      case 'question':
        response = await handleQuestion(phone, parsed, user)
        break

      default:
        response = await handleUnknown(message)
    }

    // Send the text response
    if (response) {
      await sendWhatsApp(phone, response)
    }

    // Send PDF attachment if one was generated
    if (pdfUrl) {
      await sendWhatsAppDocument(phone, pdfUrl)
    }

  } catch (err) {
    console.error('[Webhook Error]', err)
    // Don't crash — try to send a friendly error
    try {
      const phone = req.body?.From
      if (phone) {
        await sendWhatsApp(phone, `Something went wrong on my end. Please try again in a moment — sorry about that!`)
      }
    } catch (_) {}
  }
})

// ── Stripe webhook ────────────────────────────────────────────────────────────
app.post('/stripe-webhook', async (req, res) => {
  const sig = req.headers['stripe-signature']

  let event
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET)
  } catch (err) {
    console.error('Stripe webhook signature error:', err.message)
    return res.status(400).send(`Webhook Error: ${err.message}`)
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object
        const phone = session.metadata?.phone
        const plan = session.metadata?.plan || 'pro'

        if (phone) {
          await updateUser(`whatsapp:${phone}`, {
            status: 'active',
            stripe_customer_id: session.customer,
            stripe_subscription_id: session.subscription,
            plan
          })
          await sendWhatsApp(`whatsapp:${phone}`, `🎉 *You're now on the ${plan} plan!*\n\nWelcome to TradieBrain. Everything is active — just text me your next job.`)
        }
        break
      }

      case 'customer.subscription.deleted': {
        const sub = event.data.object
        // Find user by stripe customer ID and deactivate
        const { data: users } = await import('./db.js').then(m =>
          m.default.from('users').select('*').eq('stripe_customer_id', sub.customer)
        )
        if (users?.[0]) {
          await updateUser(users[0].phone, { status: 'cancelled' })
        }
        break
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object
        // Could send a WhatsApp warning here — payment failed
        console.log('Payment failed for customer:', invoice.customer)
        break
      }
    }
  } catch (err) {
    console.error('Stripe event handling error:', err)
  }

  res.json({ received: true })
})

// ── Twilio helpers ────────────────────────────────────────────────────────────
async function sendWhatsApp(to, body) {
  const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN)
  return client.messages.create({
    from: process.env.TWILIO_WHATSAPP_NUMBER,
    to,
    body
  })
}

async function sendWhatsAppDocument(to, mediaUrl) {
  const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN)
  return client.messages.create({
    from: process.env.TWILIO_WHATSAPP_NUMBER,
    to,
    body: '',
    mediaUrl: [mediaUrl]
  })
}

// ── Quick setup parser (fallback before Claude) ───────────────────────────────
function quickParseSetup(message) {
  const trades = ['plumber', 'electrician', 'gas engineer', 'builder', 'roofer',
    'decorator', 'joiner', 'carpenter', 'tiler', 'landscaper', 'hvac', 'tradesperson']

  const foundTrade = trades.find(t => message.toLowerCase().includes(t))
  const namePart = message.split(/[,\s]/)[0]

  return {
    name: namePart.charAt(0).toUpperCase() + namePart.slice(1).toLowerCase(),
    trade: foundTrade || 'tradesperson',
    isVatRegistered: /vat/i.test(message),
    isCis: /cis/i.test(message)
  }
}

// ── Start server ──────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
  console.log(`TradieBrain running on port ${PORT}`)
  console.log(`Webhook URL: ${process.env.APP_URL || `http://localhost:${PORT}`}/webhook`)
})
