import {
  getUser, createUser, updateUser, isUserActive,
  saveJob, saveExpense, getJobsForQuarter, getExpensesForQuarter,
  getJobsCurrentMonth, incrementInvoiceCount
} from './db.js'
import { parseIntent, answerQuestion } from './claude.js'
import { generateInvoicePDF, generateMTDSummary } from './pdf.js'

// ── Onboarding flow ───────────────────────────────────────────────────────────

export async function handleNewUser(phone) {
  return `👋 Welcome to *TradieBrain* — your AI admin assistant on WhatsApp!\n\nI generate professional invoices, log your expenses, and produce your HMRC MTD quarterly updates — all from a text message.\n\n*Let's get you set up.*\n\nWhat's your name and trade? For example:\n_"Dave, plumber"_ or _"Sarah, electrician"_\n\nYou've got a free 14-day trial starting now. No card needed yet.`
}

export async function handleSetup(phone, parsed) {
  const updates = {
    name: parsed.name || null,
    trade: parsed.trade || null,
    is_vat_registered: parsed.isVatRegistered || false,
    is_cis: parsed.isCis || false,
    vat_number: parsed.vatNumber || null,
    business_name: parsed.businessName || parsed.name || null,
    setup_complete: true
  }

  await updateUser(phone, updates)

  const name = parsed.name || 'there'
  const trade = parsed.trade || 'tradesperson'
  let msg = `Perfect, ${name}! You're all set up as a ${trade}. 🎉\n\n`
  msg += `*Here's what I can do for you:*\n\n`
  msg += `📄 *Invoice* — _"Invoice Mrs Davies, bathroom refit, £1,400"_\n`
  msg += `💬 *Quote* — _"Quote Mr Jones for new boiler, £2,200 labour, £600 parts"_\n`
  msg += `🧾 *Expense* — _"Expense: fuel £65"_\n`
  msg += `📊 *MTD update* — _"MTD summary"_\n`
  msg += `💰 *Revenue* — _"How much have I earned this month?"_\n`
  msg += `❓ *Any question* — _"Is my van insurance tax deductible?"_\n\n`
  msg += `One more thing — to put your bank details on invoices, just text:\n_"Bank: [account name], sort code 12-34-56, account 12345678"_`

  return msg
}

export async function handleBankSetup(phone, message) {
  // Simple parser for bank details
  const sortMatch = message.match(/(\d{2}[-\s]?\d{2}[-\s]?\d{2})/)
  const accountMatch = message.match(/(?:account\s*(?:number\s*)?:?\s*)(\d{8})/i) ||
    message.match(/(\d{8})/)

  const user = await getUser(phone)
  if (!user) return null

  const bankAccount = {
    name: user.business_name || user.name,
    sort_code: sortMatch ? sortMatch[1] : null,
    account_number: accountMatch ? accountMatch[1] : null
  }

  await updateUser(phone, { bank_account: bankAccount })
  return `✅ Bank details saved! They'll appear on all future invoices.`
}

// ── Invoice & quote ───────────────────────────────────────────────────────────

export async function handleInvoice(phone, parsed, user) {
  if (parsed.totalAmount === 0) {
    return `I didn't catch the amount. Try: _"Invoice Mrs Davies, bathroom fit, £1,400 labour, £380 materials"_`
  }

  // Generate invoice number
  const now = new Date()
  const year = now.getFullYear().toString().slice(2)
  const month = String(now.getMonth() + 1).padStart(2, '0')
  const count = String((user.invoice_count || 0) + 1).padStart(3, '0')
  parsed.invoiceNumber = `INV-${year}${month}-${count}`
  parsed.jobDate = parsed.jobDate || now.toISOString().split('T')[0]

  try {
    const pdfUrl = await generateInvoicePDF({ ...parsed, type: 'invoice' }, user)

    await saveJob(phone, {
      type: 'invoice',
      clientName: parsed.clientName,
      clientAddress: parsed.clientAddress,
      description: parsed.description,
      labourAmount: parsed.labourAmount || 0,
      materialsAmount: parsed.materialsAmount || 0,
      totalAmount: parsed.totalAmount,
      vatAmount: parsed.vatAmount || 0,
      cisDeduction: parsed.cisDeduction || 0,
      invoiceNumber: parsed.invoiceNumber,
      pdfUrl,
      jobDate: parsed.jobDate
    })

    await incrementInvoiceCount(phone)

    let msg = `✅ *Invoice created!*\n\n`
    msg += `📄 ${parsed.invoiceNumber}\n`
    msg += `👤 ${parsed.clientName}\n`
    msg += `💷 *${formatCurrency(parsed.totalAmount)}*`
    if (parsed.vatAmount > 0) msg += ` (inc. £${parsed.vatAmount.toFixed(2)} VAT)`
    if (parsed.cisDeduction > 0) msg += `\n⚠️ CIS deduction: -£${parsed.cisDeduction.toFixed(2)}`
    msg += `\n\n📎 Your invoice PDF is ready — forward it to ${parsed.clientName} directly from WhatsApp!\n\n`
    msg += `📊 This job has been logged for your MTD quarterly update.`

    return { message: msg, pdfUrl }
  } catch (err) {
    console.error('Invoice generation error:', err)
    return `Something went wrong generating your invoice. Please try again — if it keeps happening, text "help".`
  }
}

export async function handleQuote(phone, parsed, user) {
  if (parsed.totalAmount === 0) {
    return `I didn't catch the amount. Try: _"Quote Mr Jones, new boiler install, £2,200 labour, £600 parts"_`
  }

  parsed.jobDate = parsed.jobDate || new Date().toISOString().split('T')[0]

  try {
    const pdfUrl = await generateInvoicePDF({ ...parsed, type: 'quote' }, user)

    let msg = `✅ *Quote ready!*\n\n`
    msg += `📋 For: ${parsed.clientName}\n`
    msg += `💷 *${formatCurrency(parsed.totalAmount)}*\n\n`
    msg += `📎 Send the quote PDF to ${parsed.clientName} directly from here. When they accept it and you complete the job, just text me to convert it to an invoice.`

    return { message: msg, pdfUrl }
  } catch (err) {
    console.error('Quote generation error:', err)
    return `Something went wrong generating your quote. Please try again.`
  }
}

// ── Expense ───────────────────────────────────────────────────────────────────

export async function handleExpense(phone, parsed) {
  if (!parsed.amount || parsed.amount === 0) {
    return `I didn't catch the amount. Try: _"Expense: fuel £65"_ or _"Spent £42 on drill bits"_`
  }

  try {
    await saveExpense(phone, {
      description: parsed.description,
      amount: parsed.amount,
      category: parsed.category || 'other',
      date: parsed.date || new Date().toISOString().split('T')[0]
    })

    const categoryEmojis = {
      materials: '🔧', travel: '🚗', tools: '🛠️', insurance: '🛡️',
      phone: '📱', clothing: '👷', subcontractor: '👥', other: '📋'
    }
    const emoji = categoryEmojis[parsed.category] || '📋'

    return `${emoji} *Expense logged!*\n\n${parsed.description}\n💷 ${formatCurrency(parsed.amount)}\n📂 ${parsed.category || 'other'}\n\nThis will be included in your next MTD quarterly update as an allowable expense.`
  } catch (err) {
    console.error('Expense save error:', err)
    return `Couldn't save that expense. Try again in a moment.`
  }
}

// ── MTD summary ───────────────────────────────────────────────────────────────

export async function handleMTD(phone) {
  try {
    const now = new Date()
    const { quarter, year } = getCurrentQuarter(now)

    const [jobs, expenses] = await Promise.all([
      getJobsForQuarter(phone, year, quarter),
      getExpensesForQuarter(phone, year, quarter)
    ])

    if (jobs.length === 0 && expenses.length === 0) {
      return `📊 No jobs or expenses logged yet for this quarter (${getQuarterName(quarter)}).\n\nStart texting your jobs and I'll track everything for your MTD update automatically.`
    }

    return generateMTDSummary(jobs, expenses, quarter, year)
  } catch (err) {
    console.error('MTD error:', err)
    return `Couldn't pull your MTD summary right now. Try again in a moment.`
  }
}

// ── Revenue report ────────────────────────────────────────────────────────────

export async function handleRevenue(phone) {
  try {
    const jobs = await getJobsCurrentMonth(phone)
    const total = jobs.reduce((s, j) => s + Number(j.total_amount || 0), 0)
    const now = new Date()
    const monthName = now.toLocaleString('en-GB', { month: 'long' })

    if (jobs.length === 0) {
      return `💰 No invoices logged for ${monthName} yet.\n\nText me your jobs and I'll track your revenue automatically.`
    }

    let msg = `💰 *${monthName} earnings*\n\n`
    msg += `Jobs invoiced: ${jobs.length}\n`
    msg += `Total revenue: *${formatCurrency(total)}*\n\n`
    msg += `*Recent jobs:*\n`
    jobs.slice(-5).forEach(j => {
      msg += `• ${j.client_name} — ${formatCurrency(j.total_amount)}\n`
    })

    return msg
  } catch (err) {
    console.error('Revenue error:', err)
    return `Couldn't pull your revenue right now. Try again in a moment.`
  }
}

// ── General question ──────────────────────────────────────────────────────────

export async function handleQuestion(phone, parsed, user) {
  try {
    const answer = await answerQuestion(parsed.question, user)
    return answer
  } catch (err) {
    console.error('Question error:', err)
    return `Hmm, I couldn't answer that right now. Try again in a moment, or check hmrc.gov.uk for official guidance.`
  }
}

// ── Subscription ──────────────────────────────────────────────────────────────

export async function handleTrialExpired(user) {
  const planLinks = {
    starter: process.env.STRIPE_LINK_STARTER,
    pro: process.env.STRIPE_LINK_PRO,
    teams: process.env.STRIPE_LINK_TEAMS
  }

  let msg = `⏰ *Your free trial has ended*\n\n`
  msg += `To keep using TradieBrain, choose a plan:\n\n`
  msg += `📦 *Starter* — £5.99/mo (30 invoices)\n${planLinks.starter}\n\n`
  msg += `⭐ *Pro* — £9.99/mo (unlimited + logo)\n${planLinks.pro}\n\n`
  msg += `👥 *Teams* — £24/mo (up to 5 users)\n${planLinks.teams}\n\n`
  msg += `Questions? Text "help" anytime.`
  return msg
}

// ── Unknown / help ────────────────────────────────────────────────────────────

export async function handleHelp() {
  return `🤖 *TradieBrain — what I can do:*\n\n📄 *Invoice* — "Invoice [name], [job], [amount]"\n💬 *Quote* — "Quote [name], [job], [amount]"\n🧾 *Expense* — "Expense: [what] £[amount]"\n📊 *MTD* — "MTD summary"\n💰 *Earnings* — "How much this month?"\n❓ *Question* — Just ask anything\n\n*Examples:*\n_"Invoice Mrs Jones, kitchen tiling, £850"_\n_"Expense: new drill £120"_\n_"Is parking a tax deductible expense?"_`
}

export async function handleUnknown(message) {
  return `I didn't quite get that 🤔\n\nTry:\n• _"Invoice [client], [job], £[amount]"_\n• _"Expense: [what] £[amount]"_\n• _"MTD summary"_\n• Or just ask me a question\n\nText "help" to see everything I can do.`
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function formatCurrency(amount) {
  return `£${Number(amount || 0).toFixed(2)}`
}

function getCurrentQuarter(date) {
  // UK tax year: Apr 6 – Apr 5
  const month = date.getMonth() + 1
  const year = date.getFullYear()

  if (month >= 4 && month <= 7) return { quarter: 1, year }
  if (month >= 7 && month <= 10) return { quarter: 2, year }
  if (month >= 10 || month <= 1) return { quarter: 3, year }
  return { quarter: 4, year }
}

function getQuarterName(q) {
  return ['', 'Apr–Jul', 'Jul–Oct', 'Oct–Jan', 'Jan–Apr'][q]
}

export function isBankSetupMessage(message) {
  return /sort.?code|account.?number|bank.?details|bank:/i.test(message)
}

export function isNewUserSetupMessage(message) {
  // e.g. "Dave, plumber" or "Sarah electrician"
  return /^[a-z]+[,\s]+(plumber|electrician|gas engineer|builder|roofer|decorator|joiner|carpenter|tiler|landscaper|hvac|tradesperson)/i.test(message.trim())
}
