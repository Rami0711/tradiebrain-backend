import PDFDocument from 'pdfkit'
import { createClient } from '@supabase/supabase-js'
import { Readable } from 'stream'

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
)

// Colours matching TradieBrain brand
const NAVY = '#0F1C2E'
const YELLOW = '#F5C800'
const STEEL = '#8A9BB0'
const LIGHT = '#F2EFE8'
const WHITE = '#FFFFFF'

function formatCurrency(amount) {
  return `£${Number(amount).toFixed(2)}`
}

function formatDate(dateStr) {
  const d = new Date(dateStr)
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })
}

function getDueDate(dateStr, days = 30) {
  const d = new Date(dateStr)
  d.setDate(d.getDate() + days)
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })
}

export async function generateInvoicePDF(job, user) {
  return new Promise(async (resolve, reject) => {
    try {
      const doc = new PDFDocument({
        size: 'A4',
        margins: { top: 50, bottom: 50, left: 50, right: 50 }
      })

      const chunks = []
      doc.on('data', chunk => chunks.push(chunk))
      doc.on('end', async () => {
        const buffer = Buffer.concat(chunks)
        try {
          const url = await uploadPDF(buffer, job, user)
          resolve(url)
        } catch (err) {
          reject(err)
        }
      })
      doc.on('error', reject)

      const isQuote = job.type === 'quote'
      const docTitle = isQuote ? 'QUOTE' : 'INVOICE'
      const docNumber = job.invoiceNumber || generateDocNumber(isQuote)
      const pageWidth = 595 - 100 // A4 minus margins

      // ── Header bar ───────────────────────────────────
      doc.rect(0, 0, 595, 90).fill(NAVY)

      // Logo mark (simplified box shape)
      doc.save()
      doc.translate(50, 18)
      doc.polygon([0, 28], [0, 10], [16, 0], [16, 18]).fill(YELLOW)
      doc.polygon([16, 18], [16, 0], [32, 10], [32, 28]).fillOpacity(0.45).fill(YELLOW)
      doc.fillOpacity(1)
      doc.moveTo(0, 28).lineTo(16, 36).lineTo(32, 28).strokeColor(YELLOW).lineWidth(2).stroke()
      doc.restore()

      // Business name in header
      doc.font('Helvetica-Bold').fontSize(22).fillColor(WHITE)
        .text('TRADIE', 92, 22, { continued: true })
      doc.fillColor(YELLOW).text('BRAIN')

      doc.font('Helvetica').fontSize(9).fillColor(STEEL)
        .text('AI Admin for UK Tradespeople', 92, 48)

      // Document type badge (top right)
      doc.rect(430, 20, 115, 50).fill(YELLOW)
      doc.font('Helvetica-Bold').fontSize(18).fillColor(NAVY)
        .text(docTitle, 430, 32, { width: 115, align: 'center' })
      doc.font('Helvetica').fontSize(9).fillColor(NAVY)
        .text(`#${docNumber}`, 430, 52, { width: 115, align: 'center' })

      // ── From / To section ─────────────────────────────
      const fromY = 115

      // FROM block
      doc.font('Helvetica-Bold').fontSize(8).fillColor(STEEL)
        .text('FROM', 50, fromY)
      doc.font('Helvetica-Bold').fontSize(11).fillColor(NAVY)
        .text(user.business_name || user.name || 'TradieBrain User', 50, fromY + 14)
      doc.font('Helvetica').fontSize(9).fillColor(NAVY)
        .text(user.address || '', 50, fromY + 28, { width: 200 })
      if (user.phone) {
        doc.text(formatPhone(user.phone), 50, fromY + 42)
      }
      if (user.email) {
        doc.text(user.email, 50, fromY + 54)
      }
      if (user.vat_number) {
        doc.font('Helvetica').fontSize(8).fillColor(STEEL)
          .text(`VAT No: ${user.vat_number}`, 50, fromY + 68)
      }

      // Divider line between from/to
      doc.rect(260, fromY - 5, 1, 90).fill(LIGHT)

      // TO block
      doc.font('Helvetica-Bold').fontSize(8).fillColor(STEEL)
        .text('TO', 270, fromY)
      doc.font('Helvetica-Bold').fontSize(11).fillColor(NAVY)
        .text(job.client_name || 'Client', 270, fromY + 14)
      if (job.client_address) {
        doc.font('Helvetica').fontSize(9).fillColor(NAVY)
          .text(job.client_address, 270, fromY + 28, { width: 240 })
      }

      // Date info (right column)
      const dateX = 430
      doc.font('Helvetica-Bold').fontSize(8).fillColor(STEEL).text('DATE', dateX, fromY)
      doc.font('Helvetica').fontSize(9).fillColor(NAVY)
        .text(formatDate(job.job_date), dateX, fromY + 14)

      if (!isQuote) {
        doc.font('Helvetica-Bold').fontSize(8).fillColor(STEEL).text('DUE DATE', dateX, fromY + 36)
        doc.font('Helvetica').fontSize(9).fillColor(NAVY)
          .text(getDueDate(job.job_date), dateX, fromY + 50)
      }

      // ── Line items table ──────────────────────────────
      const tableY = fromY + 110
      const col = { desc: 50, qty: 340, unit: 400, total: 460 }
      const rowH = 32

      // Table header
      doc.rect(50, tableY, pageWidth, 26).fill(NAVY)
      doc.font('Helvetica-Bold').fontSize(9).fillColor(WHITE)
        .text('Description', col.desc + 8, tableY + 8)
        .text('Qty', col.qty, tableY + 8)
        .text('Unit price', col.unit, tableY + 8)
        .text('Amount', col.total, tableY + 8)

      // Row 1 — Labour
      let rowY = tableY + 26
      if (job.labour_amount > 0) {
        doc.rect(50, rowY, pageWidth, rowH).fill(WHITE)
        doc.rect(50, rowY, pageWidth, rowH).stroke(LIGHT).lineWidth(0.5)
        doc.font('Helvetica').fontSize(9).fillColor(NAVY)
          .text(job.description || 'Labour', col.desc + 8, rowY + 10, { width: 280 })
          .text('1', col.qty, rowY + 10)
          .text(formatCurrency(job.labour_amount), col.unit, rowY + 10)
          .text(formatCurrency(job.labour_amount), col.total, rowY + 10)
        rowY += rowH
      }

      // Row 2 — Materials
      if (job.materials_amount > 0) {
        doc.rect(50, rowY, pageWidth, rowH).fill(LIGHT)
        doc.rect(50, rowY, pageWidth, rowH).stroke(LIGHT).lineWidth(0.5)
        doc.font('Helvetica').fontSize(9).fillColor(NAVY)
          .text('Materials & parts', col.desc + 8, rowY + 10)
          .text('1', col.qty, rowY + 10)
          .text(formatCurrency(job.materials_amount), col.unit, rowY + 10)
          .text(formatCurrency(job.materials_amount), col.total, rowY + 10)
        rowY += rowH
      }

      // ── Totals ────────────────────────────────────────
      const totalsX = 380
      rowY += 12

      const subtotal = (job.labour_amount || 0) + (job.materials_amount || 0)

      doc.font('Helvetica').fontSize(9).fillColor(STEEL)
        .text('Subtotal', totalsX, rowY)
        .text(formatCurrency(subtotal), col.total, rowY)
      rowY += 18

      if (job.vat_amount > 0) {
        doc.text('VAT (20%)', totalsX, rowY)
          .text(formatCurrency(job.vat_amount), col.total, rowY)
        rowY += 18
      }

      if (job.cis_deduction > 0) {
        doc.fillColor('#E53935')
          .text('CIS deduction (20%)', totalsX, rowY)
          .text(`-${formatCurrency(job.cis_deduction)}`, col.total, rowY)
        rowY += 18
      }

      // Total due box
      rowY += 4
      doc.rect(totalsX - 10, rowY, pageWidth - totalsX + 60, 34).fill(NAVY)
      doc.font('Helvetica-Bold').fontSize(12).fillColor(WHITE)
        .text(isQuote ? 'QUOTE TOTAL' : 'TOTAL DUE', totalsX, rowY + 10)
        .text(formatCurrency(job.total_amount), col.total, rowY + 10)

      // ── Payment details ───────────────────────────────
      if (!isQuote && user.bank_account) {
        const payY = rowY + 60
        doc.rect(50, payY, pageWidth, 1).fill(LIGHT)

        doc.font('Helvetica-Bold').fontSize(9).fillColor(NAVY)
          .text('Payment details', 50, payY + 12)
        doc.font('Helvetica').fontSize(9).fillColor(NAVY)
          .text(`Account name: ${user.bank_account.name || user.business_name || user.name}`, 50, payY + 26)
          .text(`Sort code: ${user.bank_account.sort_code || ''}`, 50, payY + 40)
          .text(`Account number: ${user.bank_account.account_number || ''}`, 50, payY + 54)
      }

      // ── Footer ────────────────────────────────────────
      const footerY = 760
      doc.rect(0, footerY, 595, 82).fill(NAVY)
      doc.font('Helvetica').fontSize(8).fillColor(STEEL)
        .text('Generated by TradieBrain · tradiebrain.co.uk · AI Admin for UK Tradespeople', 50, footerY + 20, {
          width: pageWidth, align: 'center'
        })
      if (!isQuote) {
        doc.font('Helvetica').fontSize(8).fillColor(YELLOW)
          .text(`Payment due within 30 days · Thank you for your business`, 50, footerY + 38, {
            width: pageWidth, align: 'center'
          })
      }
      doc.font('Helvetica').fontSize(7).fillColor(STEEL)
        .text(`${user.business_name || user.name || 'TradieBrain'} is a sole trader.`, 50, footerY + 56, {
          width: pageWidth, align: 'center'
        })

      doc.end()
    } catch (err) {
      reject(err)
    }
  })
}

async function uploadPDF(buffer, job, user) {
  const timestamp = Date.now()
  const docType = job.type === 'quote' ? 'quote' : 'invoice'
  const phone = user.phone.replace(/\D/g, '')
  const filename = `${phone}/${docType}_${timestamp}.pdf`

  const { error } = await supabase.storage
    .from('documents')
    .upload(filename, buffer, {
      contentType: 'application/pdf',
      upsert: false
    })

  if (error) throw error

  const { data: urlData } = supabase.storage
    .from('documents')
    .getPublicUrl(filename)

  return urlData.publicUrl
}

function generateDocNumber(isQuote) {
  const prefix = isQuote ? 'Q' : 'INV'
  const now = new Date()
  const year = now.getFullYear().toString().slice(2)
  const month = String(now.getMonth() + 1).padStart(2, '0')
  const rand = String(Math.floor(Math.random() * 9000) + 1000)
  return `${prefix}-${year}${month}-${rand}`
}

function formatPhone(phone) {
  // Strip whatsapp: prefix
  return phone.replace('whatsapp:', '').trim()
}

export function generateMTDSummary(jobs, expenses, quarter, year) {
  const totalIncome = jobs.reduce((s, j) => s + Number(j.total_amount || 0), 0)
  const totalExpenses = expenses.reduce((s, e) => s + Number(e.amount || 0), 0)
  const profit = totalIncome - totalExpenses

  const quarterNames = { 1: 'Q1 (Apr–Jul)', 2: 'Q2 (Jul–Oct)', 3: 'Q3 (Oct–Jan)', 4: 'Q4 (Jan–Apr)' }
  const deadlines = { 1: '7 August', 2: '7 November', 3: '7 February', 4: '7 May' }

  const expenseByCategory = {}
  expenses.forEach(e => {
    expenseByCategory[e.category] = (expenseByCategory[e.category] || 0) + Number(e.amount)
  })

  let summary = `📊 *TradieBrain MTD Summary*\n`
  summary += `${quarterNames[quarter]} ${year}\n\n`
  summary += `💰 *Income*\n`
  summary += `Total invoiced: ${formatCurrency(totalIncome)}\n`
  summary += `Jobs completed: ${jobs.length}\n\n`
  summary += `📋 *Allowable expenses*\n`

  Object.entries(expenseByCategory).forEach(([cat, amt]) => {
    summary += `${cat.charAt(0).toUpperCase() + cat.slice(1)}: ${formatCurrency(amt)}\n`
  })

  summary += `Total expenses: ${formatCurrency(totalExpenses)}\n\n`
  summary += `📈 *Taxable profit*\n`
  summary += `${formatCurrency(profit)}\n\n`
  summary += `⏰ *HMRC deadline*\n`
  summary += `Submit by ${deadlines[quarter]}\n\n`
  summary += `✅ *Next step*\n`
  summary += `Log into your MTD software (HMRC bridging or free tool like TaxCalc) and enter these figures. Reply "help mtd submit" if you need step-by-step guidance.`

  return summary
}
